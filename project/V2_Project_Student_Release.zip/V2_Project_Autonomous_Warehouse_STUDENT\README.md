# Project: Autonomous Warehouse Robot — Full Navigation Loop
### Capstone · Introduction to Robotics for AI & Data Science (V2)
*Dr. Akram Fatayer · Al-Zaytoonah University of Jordan*

---

## What You're Building

One robot that does the whole job: it **senses**, **localizes itself**,
**maps** the warehouse, **plans** a path, **drives** it, and **replans** when a
box drops in its way. Every technique comes from a lab you have already done.

```
[1] SENSE & SPAWN   (Lab 1)
[2] LOCALIZE        (Lab 3 — Kalman filter)
[3] MAP             (Lab 4 — LiDAR occupancy grid)
[4] PLAN            (Lab 5 — A*)
[5] TRACK           (Lab 6 — Pure Pursuit)
[6] REPLAN          (all — dynamic obstacle)
```

---

## Your Tasks

Complete the `TODO`s in the four stage modules, then the integration TODOs in
`project_main.py`. Each module has a `__main__` self-test — get it to print
`[OK]` before moving on.

| File | What you implement | Lab |
|---|---|---|
| `modules/stage2_localization.py` | Kalman predict, update, tune Q/R | 3 |
| `modules/stage3_mapping.py` | world_to_grid, scan update, inflation | 4 |
| `modules/stage4_planning.py` | Manhattan heuristic, A\* loop | 5 |
| `modules/stage5_tracking.py` | look-ahead point, steering law | 6 |
| `project_main.py` | 6 TODOs wiring the stages together | all |

---

## How to Work

```bash
conda activate robotics_YourName

# Test each stage ALONE first — each prints [OK] when correct
python modules/stage2_localization.py
python modules/stage3_mapping.py
python modules/stage4_planning.py
python modules/stage5_tracking.py

# Once all four pass, run the full loop
python project_main.py             # with the PyBullet window
python project_main.py --headless  # fast, no window

# Check your grade any time
python grade_project.py
```

---

## Grading (30 pts)

| Layer | Points | How it's scored |
|---|---|---|
| Correctness floor | 15 | Pass/fail per stage. A complete, working pipeline earns all 15. |
| Performance gradient | 10 | Measured metrics, averaged over 5 seeds, vs fixed thresholds. |
| Differentiators | 5 | Instructor-marked (analysis, extension, overall quality). |

**Be aware:** a correct, working solution scores about **25/30**, not 30. The
top points are awarded by the instructor based on your report and extension.
Finishing the assignment is a strong grade; excellence is going past it.

Run `python grade_project.py` to see your live score broken down by layer.

---

## Deliverables

1. Your completed code, zipped as `YourName_StudentID_Project.zip`
2. `grading_output.txt` — paste of your `grade_project.py` summary
3. A 1–3 minute video of your PyBullet run (localize → plan → track → replan)
4. A 1–2 page report: your analysis + a description of your extension

---

## Tips

- A poor map makes A\* fail or detour — get Stage 3 solid before blaming Stage 4.
- The controller uses your **estimated** pose, so a noisy Kalman filter shows up
  as bad tracking. The stages really do depend on each other.
- If A\* finds no path, your inflation radius may be too large — try a smaller one.
- Tune `Q` and `R` in the Kalman filter and the look-ahead `Ld` in Pure Pursuit;
  these directly move your performance-gradient score.

---

*Dr. Akram Fatayer · a.fatayer@zuj.edu.jo · Al-Zaytoonah University of Jordan*
