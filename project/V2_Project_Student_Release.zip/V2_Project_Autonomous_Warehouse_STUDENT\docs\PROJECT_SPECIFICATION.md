# Project: Autonomous Warehouse Robot — Full Navigation Loop

**Course:** Introduction to Robotics for AI & Data Science (V2)
**Instructor:** Dr. Akram Fatayer · a.fatayer@zuj.edu.jo
**Total Points:** 30

---

## Overview

You will integrate everything from Labs 1–6 into one autonomous system. Your
robot must **sense** its surroundings, **localize** itself with a Kalman filter,
**map** the warehouse from LiDAR, **plan** a path with A\*, **track** that path
with a Pure Pursuit controller, and **replan** when a dynamic obstacle blocks
its route.

Unlike a sequence of disconnected exercises, every stage feeds the next — a poor
map yields a poor plan, a poor pose estimate yields poor tracking. The project
rewards a pipeline that works *together*.

---

## The Pipeline

```
[1] SENSE & SPAWN   Lab 1   build warehouse, spawn Husky, read sensors
        |
[2] LOCALIZE        Lab 3   Kalman filter fuses noisy odometry + GPS
        |
[3] MAP             Lab 4   LiDAR ray-cast -> occupancy grid (+ inflation)
        |
[4] PLAN            Lab 5   A* on the grid: start -> goal
        |
[5] TRACK           Lab 6   Pure Pursuit drives the planned path
        |
[6] REPLAN          all     obstacle drops -> detect, re-run A*, continue
```

---

## What You Implement

Each stage module has a small number of clearly-marked `TODO`s that call on the
exact technique from its lab. Test each module on its own (every module has a
`__main__` self-test) before wiring them together.

| Module | TODOs | From |
|---|---|---|
| `modules/stage2_localization.py` | predict, update, tune Q/R | Lab 3 |
| `modules/stage3_mapping.py` | world_to_grid, scan update, inflation | Lab 4 |
| `modules/stage4_planning.py` | heuristic, A\* loop | Lab 5 |
| `modules/stage5_tracking.py` | look-ahead point, steering law | Lab 6 |
| `project_main.py` | 6 integration TODOs wiring the stages | all |

---

## Grading (30 points)

Grading uses three layers so that **a fully-correct solution earns about 25**,
and the top of the range requires going further. This produces a fair spread
rather than everyone who finishes scoring 30.

### Layer 1 — Correctness floor (15 pts) · pass/fail per stage

Each stage either works or it does not. Get the whole pipeline working correctly
and you earn the full 15. This is the solid baseline a complete solution reaches.

| Check | Points |
|---|---|
| Stage 2 — Kalman filter fuses sensors (beats raw GPS) | 4 |
| Stage 3 — mapping builds a valid occupancy grid | 4 |
| Stage 4 — A\* returns a valid, collision-free path | 4 |
| Stage 5 — Pure Pursuit reaches the end of the path | 3 |

### Layer 2 — Performance gradient (10 pts) · measured, averaged, banded

Scored on metrics **averaged over 5 fixed random seeds** (so luck doesn't decide
your grade) and compared against **fixed physical thresholds** (so you're graded
against the physics, not against your classmates).

| Metric | Full marks | Points |
|---|---|---|
| Mean pose error (localization) | ≤ ~0.20 m | 4 |
| Path length vs optimal (planning) | optimal | 3 |
| Mean cross-track error (tracking) | ≤ ~0.10 m | 3 |

Bands are generous near the top and steep at the bottom: the gap between *good*
and *excellent* is real but small; the gap between *barely working* and *working
well* is large.

### Layer 3 — Differentiators (5 pts) · instructor-marked

| Component | Points | Marked by |
|---|---|---|
| Written analysis, extension quality, replan robustness, etc. | 5 | instructor |

> **The honest math:** a correct, working solution scores ~25/30. The last
> 5 points are awarded by the instructor based on the quality of your report,
> extension, and overall polish. A perfect 30 means you went well past "it works".

---

## Deliverables

1. **Code** — your completed modules + `project_main.py`, zipped as
   `YourName_StudentID_Project.zip`.
2. **Auto-grader output** — run `python grade_project.py` and paste the summary
   into `grading_output.txt`.
3. **Video (1–3 min)** — your PyBullet run showing the robot localizing, planning,
   tracking, and replanning around the dropped obstacle. Narrate briefly.
4. **Report (1–2 pages)** — your written analysis and a description of your
   extension.

---

## Getting Started

```bash
# 1. Environment (same as the labs)
conda activate robotics_YourName

# 2. Test each stage on its own FIRST
python modules/stage2_localization.py
python modules/stage3_mapping.py
python modules/stage4_planning.py
python modules/stage5_tracking.py

# 3. Run the full loop
python project_main.py            # with GUI
python project_main.py --headless # quick, no GUI

# 4. Grade yourself
python grade_project.py
```

Work stage by stage. A passing self-test on each module is the green light to
move on. Only wire the full loop together once all four stages pass alone.

---

## Academic Integrity

Discuss concepts freely; do not share code. All submitted code must be your own.
