"""
V2 Project - Auto-Grader
=========================

Implements the HYBRID grading scheme:

  1. CORRECTNESS FLOOR (15 pts) -- pass/fail per stage.
     Each stage either works or it does not. A fully-working pipeline
     earns this floor.

  2. PERFORMANCE GRADIENT (10 pts) -- graded on metrics, AVERAGED over
     several fixed random seeds, scored against fixed physical
     thresholds (not against other students). This is where good vs
     excellent separates.

  3. DIFFERENTIATORS (5 pts) -- all five points are instructor-marked.
     The auto-grader runs a replan diagnostic for your reference but
     awards no automatic points.

A correct solution lands around 25/30. The last points require tuning,
analysis, and an extension -- so the class spreads into a curve instead
of piling up at 30.

This grader runs WITHOUT PyBullet -- it exercises the student's stage
modules on synthetic-but-faithful problems so it can run anywhere
(including CI) and produce repeatable scores.
"""

import sys
import os
import math
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "modules"))

RESULTS = []


def banner(title):
    print("=" * 64)
    print(f"  {title}")
    print("=" * 64)


def line(label, value):
    print(f"  {label:<42}{value}")


# ======================================================================
# 1. CORRECTNESS FLOOR  (15 pts)  -- pass/fail per stage
# ======================================================================

def grade_correctness():
    banner("1. CORRECTNESS FLOOR (15 pts)")
    pts = 0
    checks = []

    # --- Stage 2: Kalman filter runs and beats raw GPS ---
    try:
        from stage2_localization import KalmanLocalizer, NoisySensors
        dt = 0.1
        kf = KalmanLocalizer(dt=dt, gps_noise_std=0.5, init_pos=(0, 0))
        s  = NoisySensors(gps_noise_std=0.5, seed=1)
        tx, ty, errs = 0.0, 0.0, []
        for _ in range(60):
            tx += 1.0 * dt; ty += 0.5 * dt
            ex, ey = kf.step(s.gps((tx, ty)))
            errs.append(math.hypot(ex - tx, ey - ty))
        ok = np.mean(errs) < 0.5
        checks.append(("Stage 2 - Kalman filter fuses sensors", ok, 4))
    except Exception as e:
        checks.append((f"Stage 2 - error: {e}", False, 4))

    # --- Stage 3: mapping builds a grid with obstacles ---
    try:
        from stage3_mapping import OccupancyGrid
        g = OccupancyGrid(width=12, height=12, resolution=0.25)
        angles = np.linspace(-np.pi, np.pi, 120, endpoint=False)
        ranges = np.full_like(angles, 4.0)
        g.update_from_scan(0, 0, ranges, angles)
        binary = g.get_binary_grid()
        centre_ok = g.world_to_grid(0, 0) == (g.rows // 2, g.cols // 2)
        ok = binary.sum() > 0 and centre_ok
        checks.append(("Stage 3 - mapping builds occupancy grid", ok, 4))
    except Exception as e:
        checks.append((f"Stage 3 - error: {e}", False, 4))

    # --- Stage 4: A* finds a valid path ---
    try:
        from stage4_planning import a_star
        grid = np.zeros((20, 20), dtype=int)
        grid[5:15, 10] = 1
        path, _ = a_star(grid, (2, 2), (18, 18))
        ok = (path is not None and path[0] == (2, 2) and path[-1] == (18, 18)
              and all(grid[r, c] == 0 for r, c in path))
        checks.append(("Stage 4 - A* finds a valid path", ok, 4))
    except Exception as e:
        checks.append((f"Stage 4 - error: {e}", False, 4))

    # --- Stage 5: Pure Pursuit tracks a path to the end ---
    try:
        from stage5_tracking import PurePursuitController
        t = np.linspace(0, 10, 200)
        path = np.column_stack((t, 2.0 * np.sin(t / 2.0)))
        ctrl = PurePursuitController(lookahead=0.8, target_speed=0.8)
        x, y, th, dt = 0.0, 0.5, 0.0, 0.05
        done = False
        for _ in range(4000):
            v, w, done = ctrl.compute_control(x, y, th, path)
            if done:
                break
            x += v * math.cos(th) * dt
            y += v * math.sin(th) * dt
            th += w * dt
        checks.append(("Stage 5 - Pure Pursuit reaches the end", done, 3))
    except Exception as e:
        checks.append((f"Stage 5 - error: {e}", False, 3))

    for label, ok, p in checks:
        line(("[OK] " if ok else "[!!] ") + label, f"{p if ok else 0}/{p}")
        if ok:
            pts += p

    print("-" * 64)
    line("Correctness subtotal", f"{pts}/15")
    print()
    return pts


# ======================================================================
# 2. PERFORMANCE GRADIENT (10 pts)  -- averaged over seeds, fixed bands
# ======================================================================

def _band(value, thresholds, points):
    """
    Map a metric to points. thresholds ascending (lower = better here),
    points descending. Returns the points for the first threshold the
    value is <= to, else 0.
    """
    for t, p in zip(thresholds, points):
        if value <= t:
            return p
    return 0


def grade_performance():
    banner("2. PERFORMANCE GRADIENT (10 pts)")
    print("  Averaged over 5 fixed seeds; scored vs physical thresholds.\n")

    # --- Localization accuracy (4 pts) ---
    loc_pts = 0
    try:
        from stage2_localization import KalmanLocalizer, NoisySensors
        seed_errs = []
        for seed in range(5):
            dt = 0.1
            kf = KalmanLocalizer(dt=dt, gps_noise_std=0.5, init_pos=(0, 0))
            s  = NoisySensors(gps_noise_std=0.5, seed=seed)
            tx, ty, errs = 0.0, 0.0, []
            # Smooth, realistic motion: constant forward + gently curving
            # lateral velocity (a velocity the CV model can actually track).
            for k in range(80):
                vy = 0.3 * math.cos(k * 0.05)   # m/s, smoothly varying
                tx += 1.0 * dt
                ty += vy * dt
                ex, ey = kf.step(s.gps((tx, ty)))
                errs.append(math.hypot(ex - tx, ey - ty))
            seed_errs.append(np.mean(errs))
        mean_err = float(np.mean(seed_errs))
        loc_pts = _band(mean_err, [0.20, 0.28, 0.38, 0.55], [4, 3, 2, 1])
        line(f"Mean pose error  = {mean_err:.3f} m", f"{loc_pts}/4")
    except Exception as e:
        line(f"Localization error: {e}", "0/4")

    # --- Planning quality (3 pts): path optimality on a known grid ---
    plan_pts = 0
    try:
        from stage4_planning import a_star, path_length
        grid = np.zeros((20, 20), dtype=int)
        grid[5:15, 10] = 1
        path, _ = a_star(grid, (2, 2), (18, 18))
        length = path_length(path)
        # Optimal length for this grid is 32 (Manhattan + detour around wall)
        plan_pts = _band(length, [32, 36, 42, 60], [3, 2, 1, 0])
        line(f"Path length      = {length} steps (optimal ~32)", f"{plan_pts}/3")
    except Exception as e:
        line(f"Planning error: {e}", "0/3")

    # --- Tracking performance (3 pts): mean cross-track error ---
    trk_pts = 0
    try:
        from stage5_tracking import PurePursuitController
        t = np.linspace(0, 10, 200)
        path = np.column_stack((t, 2.0 * np.sin(t / 2.0)))
        ctrl = PurePursuitController(lookahead=0.8, target_speed=0.8)
        x, y, th, dt = 0.0, 0.5, 0.0, 0.05
        errs = []
        for _ in range(4000):
            v, w, done = ctrl.compute_control(x, y, th, path)
            if done:
                break
            x += v * math.cos(th) * dt
            y += v * math.sin(th) * dt
            th += w * dt
            errs.append(np.min(np.linalg.norm(path - np.array([x, y]), axis=1)))
        cte = float(np.mean(errs)) if errs else 9.9
        trk_pts = _band(cte, [0.10, 0.20, 0.35, 0.60], [3, 2, 1, 0])
        line(f"Mean cross-track = {cte:.3f} m", f"{trk_pts}/3")
    except Exception as e:
        line(f"Tracking error: {e}", "0/3")

    subtotal = loc_pts + plan_pts + trk_pts
    print("-" * 64)
    line("Performance subtotal", f"{subtotal}/10")
    print()
    return subtotal


# ======================================================================
# 3. DIFFERENTIATORS (5 pts) -- instructor-marked
# ======================================================================

def grade_differentiators():
    banner("3. DIFFERENTIATORS (5 pts)")
    print("  All 5 points are marked by the instructor.")
    print("  The replan check below is DIAGNOSTIC only -- it shows whether")
    print("  your A* can re-route around a dropped obstacle, but it does")
    print("  not contribute auto-graded points.\n")

    try:
        from stage4_planning import a_star
        grid = np.zeros((20, 20), dtype=int)
        grid[5:15, 10] = 1
        path1, _ = a_star(grid, (2, 2), (18, 18))

        mid = path1[len(path1) // 2]
        grid2 = grid.copy()
        r, c = mid
        grid2[max(0, r-1):r+2, max(0, c-1):c+2] = 1

        path2, _ = a_star(grid2, (2, 2), (18, 18))
        ok = (path2 is not None and all(grid2[rr, cc] == 0 for rr, cc in path2))
        line(("[OK] " if ok else "[!!] ") + "Replan diagnostic (no auto pts)",
             "pass" if ok else "fail")
    except Exception as e:
        line(f"Replan diagnostic error: {e}", "fail")

    print("-" * 64)
    line("Differentiators (instructor)", "__/5")
    print()
    return 0


# ======================================================================
# MAIN
# ======================================================================

def main():
    banner("V2 PROJECT AUTO-GRADER")
    print("  Hybrid scheme: correctness floor + performance + differentiators")
    print("  A fully-correct solution scores ~25/30. The last 5 pts are")
    print("  instructor-marked (analysis, extension, replan quality).\n")

    c = grade_correctness()
    p = grade_performance()
    d = grade_differentiators()

    auto_total = c + p + d
    banner("SUMMARY")
    line("Correctness floor", f"{c}/15")
    line("Performance gradient", f"{p}/10")
    line("Differentiators (instructor-marked)", "__/5")
    print("-" * 64)
    line("AUTO-GRADED TOTAL", f"{auto_total}/25")
    line("Instructor-marked differentiators", "__/5")
    print("-" * 64)
    line("PROJECT TOTAL (after instructor marking)", f"{auto_total} + __ /30")
    print()
    if auto_total >= 22:
        print("  Excellent -- a strong, well-tuned solution.")
    elif auto_total >= 18:
        print("  Solid -- the pipeline works; tune for more performance points.")
    elif auto_total >= 12:
        print("  Partial -- some stages work; review the failing checks above.")
    else:
        print("  Keep going -- focus on getting each stage's self-test to pass.")


if __name__ == "__main__":
    main()
