"""
V2 Project - Stage 2: Localization (Kalman Filter)
====================================================

Uses the 2-D constant-velocity Kalman filter you built in LAB 3.

The robot has two noisy sensors:
  - Odometry  : integrates wheel velocities (drifts over time)
  - GPS-style : noisy absolute position fix (no drift, but jittery)

Your filter FUSES them into a single pose estimate that is better than
either sensor alone. The project grades you on how close your estimate
stays to the (hidden) ground-truth pose.

State vector:   x = [px, py, vx, vy]^T
Measurement:    z = [px, py]^T   (the noisy GPS fix)

WHAT YOU IMPLEMENT (3 TODOs):
  TODO 2.1  - the predict step      (prior)
  TODO 2.2  - the update step       (posterior, using the Kalman gain)
  TODO 2.3  - tune Q and R          (process vs measurement noise)
"""

import numpy as np


class KalmanLocalizer:
    """2-D constant-velocity Kalman filter for robot localization."""

    def __init__(self, dt=0.1, gps_noise_std=0.5, process_noise_std=0.2,
                 init_pos=(0.0, 0.0)):
        """
        Args:
            dt                : time step between updates (s)
            gps_noise_std     : std-dev of the GPS measurement noise (m)
            process_noise_std : std-dev of the motion/process noise
            init_pos          : initial (x, y) guess
        """
        self.dt = dt

        # --- State estimate [px, py, vx, vy] and covariance P ---
        self.x = np.array([init_pos[0], init_pos[1], 0.0, 0.0], dtype=float)
        self.P = np.diag([gps_noise_std**2, gps_noise_std**2, 4.0, 4.0])

        # --- State transition F (constant-velocity model) ---
        self.F = np.array([
            [1, 0, dt, 0],
            [0, 1, 0, dt],
            [0, 0, 1,  0],
            [0, 0, 0,  1],
        ], dtype=float)

        # --- Measurement matrix H (we observe position only) ---
        self.H = np.array([
            [1, 0, 0, 0],
            [0, 1, 0, 0],
        ], dtype=float)

        # ===================== TODO 2.3 — TUNE Q AND R =====================
        # GOAL: balance how much the filter trusts its motion model versus
        #       the GPS measurements.
        #   Q (process noise)     -> larger means "trust the model less".
        #   R (measurement noise) -> larger means "trust the GPS less" (smoother).
        # The defaults below already work. To improve your localization score,
        # experiment: try halving or doubling process_noise_std and gps_noise_std
        # and watch the mean error printed by the self-test.
        # ===================================================================
        s2 = process_noise_std ** 2
        self.Q = s2 * np.array([
            [dt**4/4, 0,        dt**3/2, 0      ],
            [0,        dt**4/4, 0,        dt**3/2],
            [dt**3/2, 0,        dt**2,    0      ],
            [0,        dt**3/2, 0,        dt**2  ],
        ], dtype=float)

        self.R = np.eye(2) * (gps_noise_std ** 2)

        self.I = np.eye(4)

    # ------------------------------------------------------------------
    def predict(self):
        """
        PREDICT STEP (prior).

        Propagate the state and covariance forward using the motion model:
            x_pred = F x
            P_pred = F P F^T + Q

        TODO 2.1: implement the two lines below.
        """
        # ===================== TODO 2.1 — PREDICT STEP =====================
        # GOAL: move the estimate one time-step forward using the motion model,
        #       BEFORE looking at any new measurement.
        #
        # YOU HAVE (already defined in __init__, all NumPy arrays):
        #   self.x  -> current state vector [px, py, vx, vy]
        #   self.P  -> current covariance matrix (4x4)
        #   self.F  -> state-transition matrix (4x4)
        #   self.Q  -> process-noise matrix (4x4)
        #
        # DO TWO THINGS (see "Kalman Filter - PREDICT" on the formula sheet):
        #   1. New state      = F applied to the current state.
        #   2. New covariance = F applied to P from both sides, then add Q.
        #
        # In NumPy, matrix multiply is the @ operator, and .T gives the transpose.
        # So a line looks like:   self.x = self.F @ self.x
        #
        # Replace the line below with your two lines.
        # ===================================================================
        raise NotImplementedError(
            "TODO 2.1: set self.x = F @ x  and  self.P = F @ P @ F.T + Q "
            "(see PREDICT on the formula sheet)")
        return self.x.copy()

    # ------------------------------------------------------------------
    def update(self, z):
        """
        UPDATE STEP (posterior) using a GPS measurement z = [px, py].

            y = z - H x          (innovation)
            S = H P H^T + R      (innovation covariance)
            K = P H^T S^-1       (Kalman gain)
            x = x + K y
            P = (I - K H) P      (Joseph form used below for stability)

        TODO 2.2: implement the Kalman gain and the state/covariance update.
        """
        z = np.asarray(z, dtype=float)

        # Innovation
        y = z - self.H @ self.x
        S = self.H @ self.P @ self.H.T + self.R

        # ===================== TODO 2.2 — UPDATE STEP ======================
        # GOAL: correct the prediction using the new measurement z.
        #       The innovation y and its covariance S are already computed above.
        #
        # YOU HAVE:
        #   self.P  -> predicted covariance (4x4)
        #   self.H  -> measurement matrix (2x4)
        #   y       -> innovation (already computed)
        #   S       -> innovation covariance (already computed)
        #   self.I  -> 4x4 identity matrix
        #
        # DO THREE THINGS (see "Kalman Filter - UPDATE" on the formula sheet):
        #   1. Kalman gain K = P * H-transpose * inverse(S).
        #      Use np.linalg.inv(S) for the inverse.
        #   2. New state      = current state + K applied to y.
        #   3. New covariance = (I - K*H) applied to P.
        #
        # Example of the inverse + multiply:  K = self.P @ self.H.T @ np.linalg.inv(S)
        #
        # Replace the line below with your three lines.
        # ===================================================================
        raise NotImplementedError(
            "TODO 2.2: compute K = P H^T S^-1, then "
            "self.x = x + K @ y  and  self.P = (I - K @ H) @ P "
            "(see UPDATE on the formula sheet)")

        return self.x.copy()

    # ------------------------------------------------------------------
    def step(self, z):
        """Convenience: one predict + one update, returns the estimated pose."""
        self.predict()
        self.update(z)
        return self.get_position()

    def get_position(self):
        """Return the current (x, y) estimate."""
        return float(self.x[0]), float(self.x[1])

    def get_state(self):
        """Return the full [px, py, vx, vy] estimate."""
        return self.x.copy()


# ----------------------------------------------------------------------
# Noisy sensor simulator (provided -- you do not modify this)
# ----------------------------------------------------------------------

class NoisySensors:
    """
    Wraps the PyBullet ground-truth pose and adds realistic noise so the
    Kalman filter has something to fuse.
    """

    def __init__(self, gps_noise_std=0.5, odom_drift=0.02, seed=0):
        self.gps_noise_std = gps_noise_std
        self.odom_drift    = odom_drift
        self.rng           = np.random.default_rng(seed)
        self._odom_xy      = None

    def gps(self, true_xy):
        """Noisy absolute position fix."""
        return (true_xy[0] + self.rng.normal(0, self.gps_noise_std),
                true_xy[1] + self.rng.normal(0, self.gps_noise_std))

    def odometry(self, true_xy):
        """Drifting dead-reckoning estimate (accumulates error)."""
        if self._odom_xy is None:
            self._odom_xy = list(true_xy)
        # add a small persistent drift each call
        self._odom_xy[0] += self.rng.normal(0, self.odom_drift)
        self._odom_xy[1] += self.rng.normal(0, self.odom_drift)
        return (true_xy[0] + self._odom_xy[0] - true_xy[0],
                true_xy[1] + self._odom_xy[1] - true_xy[1])


# ----------------------------------------------------------------------
# Quick self-test (run this file directly)
# ----------------------------------------------------------------------

if __name__ == "__main__":
    print("Stage 2 self-test: tracking a robot moving in a straight line\n")

    dt = 0.1
    kf = KalmanLocalizer(dt=dt, gps_noise_std=0.5, init_pos=(0, 0))
    sensors = NoisySensors(gps_noise_std=0.5, seed=42)

    true_x, true_y = 0.0, 0.0
    vx, vy = 1.0, 0.5
    errors = []

    for k in range(60):
        true_x += vx * dt
        true_y += vy * dt
        z = sensors.gps((true_x, true_y))
        ex, ey = kf.step(z)
        err = np.hypot(ex - true_x, ey - true_y)
        errors.append(err)

    print(f"  Mean estimate error : {np.mean(errors):.3f} m")
    print(f"  Final estimate error: {errors[-1]:.3f} m")
    print(f"  (Raw GPS noise std was 0.5 m -- the filter should beat that.)")
    if np.mean(errors) < 0.5:
        print("  [OK] Filter is fusing correctly.")
    else:
        print("  [!!] Filter error is high -- check predict/update or tune Q, R.")
