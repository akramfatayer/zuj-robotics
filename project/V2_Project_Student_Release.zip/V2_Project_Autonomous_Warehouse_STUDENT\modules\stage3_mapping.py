"""
V2 Project - Stage 3: Mapping (LiDAR -> Occupancy Grid)
========================================================

Uses the LiDAR ray-casting and log-odds occupancy grid from LAB 4.

The robot drives a short exploration pass. At each step it takes a LiDAR
scan and updates an occupancy grid. The finished grid is what the A*
planner (Stage 4) searches over.

WHAT YOU IMPLEMENT (3 TODOs):
  TODO 3.1  - world_to_grid coordinate conversion
  TODO 3.2  - mark a cell occupied / free from a single ray
  TODO 3.3  - inflate obstacles by a safety radius (so the robot's
              body clears the shelves)
"""

import numpy as np
import math


class OccupancyGrid:
    """2-D occupancy grid built from LiDAR scans (log-odds)."""

    def __init__(self, width=12.0, height=12.0, resolution=0.25):
        """
        Args:
            width, height : map size in metres
            resolution    : metres per cell
        """
        self.width      = width
        self.height     = height
        self.resolution = resolution

        self.cols = int(width / resolution)
        self.rows = int(height / resolution)

        # Log-odds grid: 0 = unknown, >0 = occupied, <0 = free
        self.log_odds = np.zeros((self.rows, self.cols), dtype=float)

        # Sensor model constants
        self.l_occ  = 0.85    # log-odds increment for a hit
        self.l_free = -0.4    # log-odds increment for a pass-through
        self.l_min  = -5.0
        self.l_max  =  5.0

    # ------------------------------------------------------------------
    def world_to_grid(self, x, y):
        """
        Convert world (x, y) in metres to grid (row, col).

        The world origin (0, 0) maps to the CENTRE of the grid.

        TODO 3.1: implement the conversion.
            col = int((x + width/2)  / resolution)
            row = int((y + height/2) / resolution)
        """
        # ===================== TODO 3.1 — WORLD -> GRID ====================
        # GOAL: convert a point in metres (x, y) into integer grid indices
        #       (row, col). The world origin (0,0) sits at the grid CENTRE.
        #
        # YOU HAVE:
        #   x, y            -> world coordinates in metres
        #   self.width      -> map width in metres
        #   self.height     -> map height in metres
        #   self.resolution -> metres per cell
        #
        # DO (see "Occupancy Grid - World to Grid" on the formula sheet):
        #   col = integer of (x + width/2)  / resolution
        #   row = integer of (y + height/2) / resolution
        #   then: return row, col
        # Use int(...) to truncate to an integer index.
        # ===================================================================
        raise NotImplementedError(
            "TODO 3.1: compute col and row from x, y using self.resolution "
            "and the half-width/half-height offset, then return row, col")

    def in_bounds(self, row, col):
        return 0 <= row < self.rows and 0 <= col < self.cols

    # ------------------------------------------------------------------
    def _bresenham(self, r0, c0, r1, c1):
        """Integer line between two grid cells (for marking free space)."""
        cells = []
        dr = abs(r1 - r0)
        dc = abs(c1 - c0)
        sr = 1 if r0 < r1 else -1
        sc = 1 if c0 < c1 else -1
        err = dr - dc
        r, c = r0, c0
        while True:
            cells.append((r, c))
            if r == r1 and c == c1:
                break
            e2 = 2 * err
            if e2 > -dc:
                err -= dc
                r += sr
            if e2 < dr:
                err += dr
                c += sc
        return cells

    # ------------------------------------------------------------------
    def update_from_scan(self, robot_x, robot_y, ranges, angles, hit_mask=None):
        """
        Update the grid from one LiDAR scan.

        For each beam:
          - the endpoint cell (where the beam hit) becomes more OCCUPIED
          - all cells along the beam become more FREE

        Args:
            hit_mask: optional boolean array (same length as ranges).
                      True  = ray struck a real object.
                      False = ray returned max_range without a hit (no obstacle).
                      When omitted, any range < self.width is treated as a hit.

        TODO 3.2: inside the loop, after computing the hit cell and the
        free cells along the ray, increment their log-odds. Use
        self.l_occ for the hit cell and self.l_free for the free cells,
        and clip to [self.l_min, self.l_max].
        """
        r0, c0 = self.world_to_grid(robot_x, robot_y)

        for i, (rng, ang) in enumerate(zip(ranges, angles)):
            if not np.isfinite(rng) or rng <= 0:
                continue
            if hit_mask is not None:
                hit = bool(hit_mask[i])
            else:
                hit = rng < self.width   # legacy: within map -> treat as a hit

            end_x = robot_x + rng * math.cos(ang)
            end_y = robot_y + rng * math.sin(ang)
            r1, c1 = self.world_to_grid(end_x, end_y)

            if not self.in_bounds(r1, c1):
                continue

            # Free cells along the beam (exclude the endpoint)
            ray_cells = self._bresenham(r0, c0, r1, c1)

            # ===================== TODO 3.2 — UPDATE CELLS =================
            # GOAL: a single LiDAR beam tells us two things --
            #   the cells it PASSED THROUGH are probably FREE,
            #   the cell where it STOPPED is probably OCCUPIED.
            #
            # YOU HAVE:
            #   ray_cells       -> list of (row, col) along the beam;
            #                      ray_cells[:-1] are pass-through, last is the hit
            #   r1, c1          -> the endpoint cell (where the beam stopped)
            #   hit             -> True if this beam struck an obstacle
            #   self.log_odds   -> the grid to update
            #   self.l_free     -> amount to ADD for a free cell (negative)
            #   self.l_occ      -> amount to ADD for an occupied cell (positive)
            #   self.l_min, self.l_max -> clip limits
            #   self.in_bounds(r, c)   -> True if (r,c) is inside the grid
            #
            # DO:
            #   1. For each (rr, cc) in ray_cells[:-1] that is in bounds:
            #        add self.l_free to self.log_odds[rr, cc], clipped to
            #        [self.l_min, self.l_max].  (use np.clip)
            #   2. If hit and (r1, c1) is in bounds:
            #        add self.l_occ to self.log_odds[r1, c1], clipped the same way.
            # ===============================================================
            raise NotImplementedError(
                "TODO 3.2: add self.l_free to the pass-through cells and "
                "self.l_occ to the hit cell, clipping to [l_min, l_max]")

    # ------------------------------------------------------------------
    def get_binary_grid(self, threshold=0.0):
        """
        Return a 0/1 occupancy grid: 1 = obstacle, 0 = free/unknown.
        A cell is an obstacle if its log-odds exceeds `threshold`.
        """
        return (self.log_odds > threshold).astype(int)

    # ------------------------------------------------------------------
    def inflate(self, grid, radius_cells):
        """
        Grow every obstacle by `radius_cells` in all directions so the
        planner keeps the robot's body clear of shelves.

        TODO 3.3: for each occupied cell, mark all cells within
        `radius_cells` (Chebyshev/square neighbourhood) as occupied in a
        COPY of the grid, and return the copy.
        """
        # ===================== TODO 3.3 — INFLATE OBSTACLES ================
        # GOAL: grow every obstacle outward by radius_cells so the planner
        #       keeps the robot's body clear of the shelves.
        #
        # YOU HAVE:
        #   grid          -> a 2-D array, 1 = obstacle, 0 = free
        #   radius_cells  -> how many cells to grow each obstacle
        #   self.rows, self.cols -> grid dimensions
        #
        # DO:
        #   1. Make a COPY of grid (read original, write the copy):
        #        inflated = grid.copy()
        #   2. Find every occupied cell. np.where(grid == 1) gives row/col arrays.
        #   3. For each occupied cell (r, c), set every cell in the square
        #      neighbourhood [r-radius_cells .. r+radius_cells] x
        #      [c-radius_cells .. c+radius_cells] to 1 in 'inflated'
        #      (clamp the indices to stay inside the grid).
        #   4. return inflated
        # ===================================================================
        raise NotImplementedError(
            "TODO 3.3: copy the grid, then for each occupied cell set the "
            "surrounding radius_cells neighbourhood to 1; return the copy")


# ----------------------------------------------------------------------
# Self-test: build a grid from a synthetic scan of a boxed room
# ----------------------------------------------------------------------

if __name__ == "__main__":
    print("Stage 3 self-test: mapping a synthetic room\n")

    grid = OccupancyGrid(width=12, height=12, resolution=0.25)

    # Simulate a robot at the origin scanning a square room of walls at +/-5 m
    robot_x, robot_y = 0.0, 0.0
    angles = np.linspace(-np.pi, np.pi, 180, endpoint=False)
    ranges = []
    for a in angles:
        # distance to the nearest wall of a 10x10 room centred at origin
        candidates = []
        cos_a, sin_a = math.cos(a), math.sin(a)
        for wall, comp in [(5.0, cos_a), (-5.0, cos_a), (5.0, sin_a), (-5.0, sin_a)]:
            if abs(comp) > 1e-6:
                t = wall / comp
                if t > 0:
                    candidates.append(t)
        ranges.append(min(candidates) if candidates else 10.0)
    ranges = np.array(ranges)

    grid.update_from_scan(robot_x, robot_y, ranges, angles)

    binary = grid.get_binary_grid()
    inflated = grid.inflate(binary, radius_cells=1)

    n_occ      = int(binary.sum())
    n_inflated = int(inflated.sum())
    print(f"  Grid size        : {grid.rows} x {grid.cols} cells")
    print(f"  Occupied cells   : {n_occ}")
    print(f"  After inflation  : {n_inflated}  (should be >= occupied)")
    centre = grid.world_to_grid(0, 0)
    print(f"  World (0,0) -> grid {centre} (should be near centre "
          f"{grid.rows//2},{grid.cols//2})")
    if n_occ > 0 and n_inflated >= n_occ and centre == (grid.rows//2, grid.cols//2):
        print("  [OK] Mapping pipeline works.")
    else:
        print("  [!!] Check world_to_grid / scan update / inflation.")
