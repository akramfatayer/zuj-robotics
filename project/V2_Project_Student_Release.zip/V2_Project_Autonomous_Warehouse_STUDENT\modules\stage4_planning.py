"""
V2 Project - Stage 4: Planning (A*)
====================================

Uses the A* grid search you built in LAB 5, run on the occupancy grid
your mapping stage produced.

WHAT YOU IMPLEMENT (2 TODOs):
  TODO 4.1  - the Manhattan heuristic
  TODO 4.2  - the A* main loop (pop lowest f, expand neighbours)
"""

import heapq
import numpy as np


def heuristic(a, b):
    """
    Manhattan distance between grid cells a=(r,c) and b=(r,c).

    TODO 4.1: return |dr| + |dc|.
    """
    # ===================== TODO 4.1 — MANHATTAN HEURISTIC ==================
    # GOAL: estimate the remaining cost from cell a to cell b on a
    #       4-connected grid (no diagonals).
    #
    # YOU HAVE:
    #   a -> (row, col) of the current cell
    #   b -> (row, col) of the goal cell
    #
    # DO (see "A* - Manhattan heuristic" on the formula sheet):
    #   return |row_a - row_b| + |col_a - col_b|
    # Use abs(...) for absolute value.
    # =======================================================================
    raise NotImplementedError(
        "TODO 4.1: return abs(a[0]-b[0]) + abs(a[1]-b[1])")


def get_neighbors(node, grid):
    """4-connected free neighbours of `node`."""
    neighbors = []
    rows, cols = grid.shape
    for dr, dc in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
        nr, nc = node[0] + dr, node[1] + dc
        if 0 <= nr < rows and 0 <= nc < cols and grid[nr, nc] == 0:
            neighbors.append((nr, nc))
    return neighbors


def a_star(grid, start, goal):
    """
    A* search on a 2-D occupancy grid (0 = free, 1 = obstacle).

    Args:
        grid  : 2-D numpy array
        start : (row, col)
        goal  : (row, col)

    Returns:
        path     : list of (row, col) from start to goal, or None
        explored : set of expanded cells (for metrics / visualisation)

    TODO 4.2: complete the main loop -- pop the lowest-f node, test for
    the goal, and expand neighbours updating g and f scores.
    """
    open_set = []
    heapq.heappush(open_set, (0, start))
    came_from = {}
    g_score   = {start: 0}
    explored  = set()

    while open_set:
        # ===================== TODO 4.2 — A* MAIN LOOP =====================
        # GOAL: expand the most promising node each iteration until the goal
        #       is reached.
        #
        # YOU HAVE:
        #   open_set   -> a heap of (f_score, node); use heapq.heappop/heappush
        #   came_from  -> dict mapping node -> the node we reached it from
        #   g_score    -> dict mapping node -> cost from start so far
        #   explored   -> set of nodes already finalised
        #   get_neighbors(node, grid) -> list of valid free neighbour cells
        #   heuristic(node, goal)     -> the function from TODO 4.1
        #
        # DO each iteration (see "A*  f(n)=g(n)+h(n)" on the formula sheet):
        #   1. Pop the lowest-f node from open_set. If it is already in
        #      'explored', skip it (continue); otherwise add it to 'explored'.
        #   2. If it equals the goal: rebuild the path by walking 'came_from'
        #      backwards from goal to start, reverse it, return (path, explored).
        #   3. Otherwise, for each neighbour:
        #        tentative_g = g_score[current] + 1
        #        if neighbour is new OR tentative_g < its old g_score:
        #            g_score[neighbour]  = tentative_g
        #            came_from[neighbour] = current
        #            push (tentative_g + heuristic(neighbour, goal), neighbour)
        # ===================================================================
        raise NotImplementedError(
            "TODO 4.2: pop lowest-f node, return reconstructed path if it is "
            "the goal, else expand neighbours updating g_score/came_from")

    return None, explored


def path_length(path):
    """Number of steps in a grid path (0 if None)."""
    return 0 if not path else len(path) - 1


# ----------------------------------------------------------------------
# Self-test
# ----------------------------------------------------------------------

if __name__ == "__main__":
    print("Stage 4 self-test: A* around a wall\n")

    grid = np.zeros((20, 20), dtype=int)
    grid[5:15, 10] = 1          # vertical wall with a gap at the bottom
    start = (2, 2)
    goal  = (18, 18)

    path, explored = a_star(grid, start, goal)

    if path is None:
        print("  [!!] No path found -- check the A* loop.")
    else:
        print(f"  Path length    : {path_length(path)} steps")
        print(f"  Cells explored : {len(explored)} / {grid.size}")
        print(f"  Endpoints      : {path[0]} -> {path[-1]}")
        ok = (path[0] == start and path[-1] == goal
              and all(grid[r, c] == 0 for r, c in path))
        print("  [OK] A* works." if ok else "  [!!] Path invalid.")
