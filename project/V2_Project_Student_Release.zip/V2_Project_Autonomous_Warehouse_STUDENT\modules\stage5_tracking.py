"""
V2 Project - Stage 5: Tracking (Pure Pursuit)
==============================================

Uses the Pure Pursuit controller you built in LAB 6 to physically drive
the A* path. The controller outputs (v, omega) commands that the
warehouse environment converts to wheel speeds.

WHAT YOU IMPLEMENT (2 TODOs):
  TODO 5.1  - find the look-ahead point on the path
  TODO 5.2  - the Pure Pursuit steering law
"""

import numpy as np


class PurePursuitController:
    """Geometric path-tracking controller (Lab 6)."""

    def __init__(self, wheelbase=0.555, lookahead=0.8, target_speed=0.8,
                 max_omega=2.5):
        """
        Args:
            wheelbase    : distance between wheels (m) -- Husky ~0.555
            lookahead    : look-ahead distance Ld (m)
            target_speed : forward speed command (m/s)
            max_omega    : angular-velocity clamp (rad/s)
        """
        self.L            = wheelbase
        self.Ld           = lookahead
        self.target_speed = target_speed
        self.max_omega    = max_omega

    # ------------------------------------------------------------------
    def find_lookahead_point(self, robot_xy, path):
        """
        Return the first path point at least Ld away from the robot,
        searching forward from the nearest point.

        TODO 5.1: implement the search.
        """
        path = np.asarray(path)
        dists = np.linalg.norm(path - np.asarray(robot_xy), axis=1)
        nearest = int(np.argmin(dists))

        # ===================== TODO 5.1 — LOOK-AHEAD POINT =================
        # GOAL: find the point on the path the robot should aim at -- the
        #       first one at least Ld metres ahead.
        #
        # YOU HAVE:
        #   path     -> array of (x, y) path points
        #   dists    -> distance from robot to every path point (computed above)
        #   nearest  -> index of the closest path point (computed above)
        #   self.Ld  -> the look-ahead distance
        #
        # DO:
        #   Search forward from index 'nearest'. Return the FIRST point whose
        #   distance (dists[i]) is >= self.Ld, as a tuple (point, index).
        #   If none is far enough (robot near the end), return the last point
        #   and its index: return path[-1], len(path) - 1
        # ===================================================================
        raise NotImplementedError(
            "TODO 5.1: return the first path point with dists[i] >= self.Ld "
            "(searching from 'nearest'), else the last; return (point, index)")

    # ------------------------------------------------------------------
    def compute_control(self, robot_x, robot_y, robot_theta, path):
        """
        Compute (v, omega) to drive toward the look-ahead point.

        Pure Pursuit steering (Lab 6, Slide 7):
            alpha = angle to look-ahead point, relative to robot heading
            delta = arctan(2 L sin(alpha) / Ld)        (steering angle)
            omega = v / L * tan(delta)                  (yaw rate)

        TODO 5.2: implement alpha, the steering angle, and omega.

        Returns:
            v, omega, reached_end (bool)
        """
        target, idx = self.find_lookahead_point((robot_x, robot_y), path)

        # Stop condition: close to the final waypoint
        goal = np.asarray(path[-1])
        if np.linalg.norm(goal - np.array([robot_x, robot_y])) < 0.4:
            return 0.0, 0.0, True

        # ===================== TODO 5.2 — PURE PURSUIT STEERING ============
        # GOAL: compute the (v, omega) command that steers the robot toward
        #       the look-ahead 'target'.
        #
        # YOU HAVE:
        #   robot_x, robot_y, robot_theta -> the robot's current pose
        #   target            -> the (x, y) look-ahead point from TODO 5.1
        #   self.Ld           -> look-ahead distance
        #   self.target_speed -> the forward speed to command as v
        #   self.max_omega    -> clamp limit for omega
        #
        # DO (see "Pure Pursuit" on the formula sheet):
        #   1. alpha = angle to target RELATIVE to robot heading.
        #      global angle: np.arctan2(target_y - robot_y, target_x - robot_x);
        #      then subtract robot_theta and normalise to [-pi, pi] with
        #      np.arctan2(np.sin(d), np.cos(d)).
        #   2. delta = np.arctan2(2 * self.L * np.sin(alpha), self.Ld)
        #   3. v = self.target_speed
        #      omega = (v / self.L) * np.tan(delta), clipped to
        #      [-self.max_omega, self.max_omega] with np.clip.
        #   4. return v, omega, False
        # ===================================================================
        raise NotImplementedError(
            "TODO 5.2: compute alpha (normalised), delta from the Pure Pursuit "
            "formula, then v and omega; return v, omega, False")


# ----------------------------------------------------------------------
# Self-test: drive a curved path with a kinematic robot model
# ----------------------------------------------------------------------

if __name__ == "__main__":
    print("Stage 5 self-test: tracking a curved path (kinematic)\n")

    # S-shaped reference path
    t = np.linspace(0, 10, 200)
    path = np.column_stack((t, 2.0 * np.sin(t / 2.0)))

    ctrl = PurePursuitController(lookahead=0.8, target_speed=0.8)

    x, y, theta = 0.0, 0.5, 0.0
    dt = 0.05
    L = ctrl.L
    errors = []

    for _ in range(4000):
        v, omega, done = ctrl.compute_control(x, y, theta, path)
        if done:
            break
        x += v * np.cos(theta) * dt
        y += v * np.sin(theta) * dt
        theta += omega * dt
        d = np.min(np.linalg.norm(path - np.array([x, y]), axis=1))
        errors.append(d)

    print(f"  Mean cross-track error : {np.mean(errors):.3f} m")
    print(f"  Max  cross-track error : {np.max(errors):.3f} m")
    print(f"  Reached end            : {done}")
    if done and np.mean(errors) < 0.4:
        print("  [OK] Controller tracks the path.")
    else:
        print("  [!!] Check the look-ahead search or steering law.")
