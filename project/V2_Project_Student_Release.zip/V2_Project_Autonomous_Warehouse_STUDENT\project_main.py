"""
V2 PROJECT: Autonomous Warehouse Robot - Full Navigation Loop
==============================================================

Student Name: ______________________
Student ID:   ______________________

This is the integration harness. It wires your five stage modules into a
single closed loop and drives the Husky robot through the warehouse:

    SENSE  -> LOCALIZE -> MAP -> PLAN -> TRACK -> (REPLAN if blocked)

You complete the TODOs below. Each TODO calls into a stage module you
already implemented and tested on its own.

Run:
    python project_main.py            # full run in PyBullet
    python project_main.py --headless # no GUI (for quick testing)

Grade your work:
    python grade_project.py
"""

import sys
import os
import time
import math
import argparse
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "modules"))

import pybullet as p
import pybullet_data

from warehouse_environment import WarehouseEnvironment
from stage2_localization import KalmanLocalizer, NoisySensors
from stage3_mapping import OccupancyGrid
from stage4_planning import a_star
from stage5_tracking import PurePursuitController


# Map / world configuration
MAP_W, MAP_H = 12.0, 12.0
RESOLUTION   = 0.25
DT           = 1.0 / 60.0


def grid_to_world(grid, r, c):
    x = c * grid.resolution - grid.width / 2 + grid.resolution / 2
    y = r * grid.resolution - grid.height / 2 + grid.resolution / 2
    return x, y


def lidar_scan(robot_id, num_rays=120, max_range=8.0):
    """Simple ray-cast LiDAR around the robot base."""
    pos, orn = p.getBasePositionAndOrientation(robot_id)
    yaw = p.getEulerFromQuaternion(orn)[2]
    angles = np.linspace(-np.pi, np.pi, num_rays, endpoint=False) + yaw
    starts, ends = [], []
    for a in angles:
        starts.append([pos[0], pos[1], 0.3])
        ends.append([pos[0] + max_range * math.cos(a),
                     pos[1] + max_range * math.sin(a), 0.3])
    hits = p.rayTestBatch(starts, ends)
    # h[0] == -1  → no object struck (ray reached max_range)
    # h[0] == robot_id → self-hit against the robot's own body/wheels; treat
    #                     as no-hit so we don't mark the start area as occupied.
    def _real_hit(h):
        return h[0] != -1 and h[0] != robot_id

    ranges   = np.array([h[2] * max_range if _real_hit(h) else max_range
                         for h in hits])
    hit_mask = np.array([_real_hit(h) for h in hits], dtype=bool)
    world_angles = angles
    return ranges, world_angles, hit_mask


def run(headless=False):
    print("=" * 64)
    print("  V2 PROJECT: Autonomous Warehouse Navigation")
    print("=" * 64)

    # ------------------------------------------------------------------
    # STAGE 1 - SENSE & SPAWN  (Lab 1)
    # TODO 1: create the warehouse and spawn the robot at the start.
    #   - WarehouseEnvironment(gui=not headless)
    #   - env.spawn_robot("husky", position=[start_x, start_y, 0.1])
    # ------------------------------------------------------------------
    print("\n[1/6] SENSE  - building warehouse, spawning robot ...")
    start_xy = (-4.0, -4.0)
    goal_xy  = ( 4.0,  4.0)

    env = WarehouseEnvironment(gui=not headless, warehouse_size=(12, 12))
    robot_id = env.spawn_robot("husky", position=[start_xy[0], start_xy[1], 0.1])
    for _ in range(60):
        env.step()

    # ------------------------------------------------------------------
    # STAGE 2 - LOCALIZE  (Lab 3)
    # TODO 2: create the Kalman localizer and the noisy sensor wrapper.
    # ------------------------------------------------------------------
    print("[2/6] LOCALIZE - initializing Kalman filter ...")
    kf      = KalmanLocalizer(dt=DT * 8, gps_noise_std=0.4, init_pos=start_xy)
    sensors = NoisySensors(gps_noise_std=0.4, seed=0)

    # ------------------------------------------------------------------
    # STAGE 3 - MAP  (Lab 4)
    # TODO 3: build the occupancy grid by driving a short scan pass and
    #         calling grid.update_from_scan(...) each step.
    # ------------------------------------------------------------------
    print("[3/6] MAP  - scanning the warehouse with LiDAR ...")
    grid = OccupancyGrid(width=MAP_W, height=MAP_H, resolution=RESOLUTION)

    state = env.get_robot_state()
    true_xy = (state['position'][0], state['position'][1])
    for _ in range(40):
        # rotate in place to scan surroundings
        env.move_robot(0.0, 1.2)
        env.step()
        st = env.get_robot_state()
        txy = (st['position'][0], st['position'][1])
        ranges, angles, hit_mask = lidar_scan(robot_id)
        grid.update_from_scan(txy[0], txy[1], ranges, angles, hit_mask=hit_mask)
    env.move_robot(0.0, 0.0)

    binary   = grid.get_binary_grid()
    inflated = grid.inflate(binary, radius_cells=2)

    # ------------------------------------------------------------------
    # STAGE 4 - PLAN  (Lab 5)
    # TODO 4: convert start/goal to grid cells and run A* on `inflated`.
    # ------------------------------------------------------------------
    print("[4/6] PLAN  - running A* ...")
    start_cell = grid.world_to_grid(*start_xy)
    goal_cell  = grid.world_to_grid(*goal_xy)
    path_cells, explored = a_star(inflated, start_cell, goal_cell)

    if path_cells is None:
        print("      A* found no path -- the map may be over-inflated. Aborting.")
        env.close()
        return

    path_world = np.array([grid_to_world(grid, r, c) for (r, c) in path_cells])
    print(f"      Path: {len(path_world)} waypoints, {len(explored)} cells explored.")

    if not headless:
        for i in range(len(path_world) - 1):
            p.addUserDebugLine([path_world[i][0],   path_world[i][1],   0.2],
                               [path_world[i+1][0], path_world[i+1][1], 0.2],
                               lineColorRGB=[0.1, 0.85, 0.25], lineWidth=3)

    # ------------------------------------------------------------------
    # STAGE 5 - TRACK  (Lab 6)  + STAGE 6 - REPLAN
    # TODO 5: drive the path with Pure Pursuit. Each control tick:
    #   - estimate pose with the Kalman filter (fuse noisy GPS)
    #   - compute (v, omega) from the controller
    #   - env.move_robot(v, omega)
    # TODO 6: drop a dynamic obstacle mid-route; when LiDAR detects the
    #   path is blocked, re-run A* and continue on the new path.
    # ------------------------------------------------------------------
    print("[5/6] TRACK - following the path with Pure Pursuit ...")
    ctrl = PurePursuitController(lookahead=1.0, target_speed=0.9)

    dynamic_dropped = False
    replanned       = False
    reached         = False
    cte_history     = []

    for step in range(8000):
        st   = env.get_robot_state()
        txy  = (st['position'][0], st['position'][1])
        yaw  = st['euler'][2]

        # Kalman localization from noisy GPS
        est_xy = kf.step(sensors.gps(txy))

        # Drop a dynamic obstacle halfway through (Stage 6 trigger)
        if not dynamic_dropped and step == 1200:
            mid = path_world[len(path_world) // 2]
            env.spawn_box([mid[0], mid[1], 0.3], color="red", size=0.6,
                          name="dynamic")
            dynamic_dropped = True
            print("      [!] Dynamic obstacle dropped on the path.")

        # After the drop, re-scan and replan once
        if dynamic_dropped and not replanned and step == 1260:
            ranges, angles, hit_mask = lidar_scan(robot_id)
            grid.update_from_scan(txy[0], txy[1], ranges, angles, hit_mask=hit_mask)
            binary2   = grid.get_binary_grid()
            inflated2 = grid.inflate(binary2, radius_cells=2)
            cur_cell  = grid.world_to_grid(*txy)
            new_path, _ = a_star(inflated2, cur_cell, goal_cell)
            if new_path is not None:
                path_world = np.array([grid_to_world(grid, r, c)
                                       for (r, c) in new_path])
                replanned = True
                print(f"      [+] Replanned around obstacle: "
                      f"{len(path_world)} new waypoints.")
                if not headless:
                    for i in range(len(path_world) - 1):
                        p.addUserDebugLine(
                            [path_world[i][0],   path_world[i][1],   0.25],
                            [path_world[i+1][0], path_world[i+1][1], 0.25],
                            lineColorRGB=[1.0, 0.55, 0.0], lineWidth=3)

        # Pure Pursuit control (uses the ESTIMATED pose)
        v, omega, done = ctrl.compute_control(est_xy[0], est_xy[1], yaw,
                                              path_world)
        env.move_robot(v, omega)

        # Track cross-track error against the path (using true pose)
        d = np.min(np.linalg.norm(path_world - np.array(txy), axis=1))
        cte_history.append(d)

        if done or np.linalg.norm(np.array(goal_xy) - np.array(txy)) < 0.6:
            reached = True
            env.move_robot(0.0, 0.0)
            break

        env.step(sleep_time=DT if not headless else None)

    # ------------------------------------------------------------------
    # RESULTS
    # ------------------------------------------------------------------
    print("[6/6] DONE")
    print("-" * 64)
    print(f"  Reached goal       : {reached}")
    print(f"  Replanned          : {replanned}")
    print(f"  Mean cross-track   : {np.mean(cte_history):.3f} m"
          if cte_history else "  (no motion)")
    print("-" * 64)
    print("  Record your PyBullet run for the submission video.")
    print("  Then run:  python grade_project.py")

    if not headless:
        print("\n  Close the window to exit.")
        try:
            while p.isConnected():
                env.step(sleep_time=DT)
        except Exception:
            pass
    env.close()


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--headless", action="store_true",
                    help="run without the PyBullet GUI")
    args = ap.parse_args()
    run(headless=args.headless)
